package com.example.project2;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.project2.databinding.ActivityLoginBinding;
import android.util.Log;

public class Login extends AppCompatActivity {

    private UserRepository UserRepository;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button newAccountButton;

    private Switch DarkModeSwitch;

    private ActivityLoginBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set up data binding and layout
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize UI elements
        usernameEditText = binding.userName;
        passwordEditText = binding.Password;
        loginButton = binding.SignInbutton;
        newAccountButton = binding.CreateAccount;


        // Initialize UserDatabaseHelper and UserRepository
        UserData dbHelper = new UserData(this);
        UserRepository = new UserRepository(dbHelper);

        // Set click listener for the login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleLogin();
            }
        });

        // Set click listener for the new account button
        newAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleCreateAccount();
            }
        });

        DarkModeSwitch = findViewById(R.id.DarkModeSwitch);
        // Set the initial switch state based on the current theme
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        DarkModeSwitch.setChecked(nightModeFlags == Configuration.UI_MODE_NIGHT_YES);

        // Handle switch changes
        DarkModeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
                // Recreate the activity to apply the new theme
                recreate();
            }
        });
    }



    // Handle login functionality
    private void handleLogin() {
        // Get username and password from EditText fields
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Log the username and password (do not log real passwords in production)
        Log.d("Login", "Username entered: " + username);

        // Authenticate user
        boolean isAuthenticated = UserRepository.authenticateUser(username, password);
        Log.d("Login", "Authentication result: " + isAuthenticated);

        if (isAuthenticated) {
            // Login successful
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, WelcomeScreen.class);
            startActivity(intent);
        } else {
            // Login failed
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the create account functionality
    private void handleCreateAccount() {
        // Get username and password from EditText fields
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Navigate to the accountCreation activity
        Intent intent2 = new Intent(Login.this, accountCreation.class);
        startActivity(intent2);
    }

}

