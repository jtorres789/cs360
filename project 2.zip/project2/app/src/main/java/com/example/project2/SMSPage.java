package com.example.project2;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPage extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private TextView permissionStatusTextView;
    private Button permissionButton;
    private Button SMSgoBackButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smspage);

        // Initialize views
        permissionButton = findViewById(R.id.permissionButton);
        permissionStatusTextView = findViewById(R.id.permissionStatusTextView);
        SMSgoBackButton = findViewById(R.id.SMSgoBackButton);

        // Set up click listeners
        permissionButton.setOnClickListener(v -> requestPhoneNumberAndPermissionDecision());
        SMSgoBackButton.setOnClickListener(v -> navigateToWelcomeScreen());

        // Check and update permission status
        updatePermissionStatus();
    }

    private void requestPhoneNumberAndPermissionDecision() {
        // Prompt user to enter phone number
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter your phone number");

        // Set up the input field
        final EditText phoneNumberInput = new EditText(this);
        phoneNumberInput.setInputType(InputType.TYPE_CLASS_PHONE);
        builder.setView(phoneNumberInput);

        // Set up the submit and cancel buttons
        builder.setPositiveButton("Submit", (dialog, which) -> {
            String phoneNumber = phoneNumberInput.getText().toString().trim();
            if (!phoneNumber.isEmpty()) {
                // Request SMS permission if not granted
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
                } else {
                    // Prompt permission decision dialog
                    promptPermissionDecision();
                }
            } else {
                Toast.makeText(this, "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void promptPermissionDecision() {
        // Prompt user for permission decision
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Allow SMS permission?");

        // Set up the dialog buttons
        builder.setPositiveButton("Allow", (dialog, which) -> {
            permissionStatusTextView.setText("Permission status: Granted");
            Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Deny", (dialog, which) -> {
            permissionStatusTextView.setText("Permission status: Denied");
            Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show();
        });

        builder.show();
    }

    private void updatePermissionStatus() {
        // Check SMS permission status and update the TextView
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            permissionStatusTextView.setText("Permission status: Granted");
        } else {
            permissionStatusTextView.setText("Permission status: Denied");
        }
    }

    private void navigateToWelcomeScreen() {
        // Navigate back to the welcome screen
        Intent intent = new Intent(SMSPage.this, WelcomeScreen.class);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            } else {
                Toast.makeText(this, "SMS permission denied!", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            }
        }
    }
}
