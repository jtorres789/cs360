package com.example.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class UserData extends SQLiteOpenHelper {
    //creating userdatabase
    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    public UserData(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("UserData", "Creating database and users table...");
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createTableQuery);
        Log.d("UserData", "Database and table created successfully.");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the table if it exists and recreate it
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    //when adding a user if nothing is entered
    public boolean addUser(String username, String password) {
        if (username == null || password == null) {
            Log.e("UserData", "Username or password is null");
            return false;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_PASSWORD, password);
            long result = db.insert(TABLE_NAME, null, values);
            return result != -1;
        } catch (SQLException e) {
            Log.e("UserData", "Error adding user: " + e.getMessage());
            return false;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    //check if user is entered
    public boolean checkUser(String username, String password) {
        if (username == null || password == null) {
            Log.e("UserData", "Username or password is null");
            return false;
        }

        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
            String[] selectionArgs = {username, password};
            cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null);
            boolean userExists = cursor.moveToFirst();
            return userExists;
        } catch (SQLException e) {
            Log.e("UserData", "Error checking user: " + e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }
    }
    public boolean isUserValid(String username, String password) {
        // Implement the logic to check if the user is valid
        // This might involve querying the database for the given username and password
        // and returning true if a match is found, otherwise returning false.
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                "users", // Table name
                null, // Return all columns
                "username = ? AND password = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        // Check if the query returned any rows
        boolean userValid = cursor.moveToFirst();

        // Close the cursor and database
        cursor.close();
        db.close();

        // Return whether the user is valid
        return userValid;
    }

}
