package com.example.project2;

import static androidx.core.content.ContextCompat.startActivity;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

public class displayDatabase extends SQLiteOpenHelper {
    // vairable naming and cpnnecting to the database process, naming database inventory.db
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    private static final String MY_PERMISSIONS_REQUEST_SEND_SMS = Manifest.permission.SEND_SMS; // this allows SMS in the emulator when notifying the user of low inventory

    private Context context;

    //table creation and format
    public static final class InventoryTable {
        public static final String TABLE = "inventory";
        public static final String COL_ID = "_id";
        public static final String COL_NAME = "name";
        public static final String COL_DESCRIPTION = "description";
        public static final String COL_COUNT = "count";

        //method to get the COL_ID
        public static String getColId() {
            return COL_ID;
        }
    }

    public Cursor getItemById(int itemId) { //gets item by ID
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                InventoryTable.COL_ID,
                InventoryTable.COL_NAME,
                InventoryTable.COL_DESCRIPTION,
                InventoryTable.COL_COUNT
        };

        String selection = InventoryTable.COL_ID + " = ?";
        String[] selectionArgs = {String.valueOf(itemId)};

        Cursor cursor = db.query(
                InventoryTable.TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        return cursor;
    }


    public displayDatabase(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Initialize Database
        String query = "CREATE TABLE " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InventoryTable.COL_NAME + " TEXT, " +
                InventoryTable.COL_DESCRIPTION + " TEXT, " +
                InventoryTable.COL_COUNT + " INTEGER);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE);
        onCreate(db);
    }

    // Add single item to database
    boolean addItem(String name, String description, int count) {

        // Add single item to Database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(InventoryTable.COL_NAME, name);
        cv.put(InventoryTable.COL_DESCRIPTION, description);
        cv.put(InventoryTable.COL_COUNT, count);

        long result = db.insert(InventoryTable.TABLE, null, cv);

        // Check the result and return a boolean value
        boolean success = result != -1;

        if (success) {
            smsCheck(); // this checks the function of sms warning to make sure if when adding something is low than the target it activates it
        }
        return success;

    }


    // Read all items from database
    Cursor readItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryTable.TABLE, null);

        return cursor;
    }
    // this handles editing an iem in the database and returns if it could or not
    boolean editItem(String rowId, String name, String description, int count) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(InventoryTable.COL_NAME, name);
        cv.put(InventoryTable.COL_DESCRIPTION, description);
        cv.put(InventoryTable.COL_COUNT, count);

        long result = db.update(InventoryTable.TABLE, cv, "_id=?", new String[]{rowId});
        boolean success = result != -1;

        if (success) {
            Toast.makeText(context, "Updated Item!", Toast.LENGTH_SHORT).show();
            Intent intent5 = new Intent(context, displayInventoryActivity.class);
            context.startActivity(intent5);

            // Call smsCheck() after a successful update
            smsCheck();
        } else {
            Toast.makeText(context, "Failed to Update Item!", Toast.LENGTH_SHORT).show();
        }

        db.close();  // Close the database connection
        return success;  // Return whether the update was successful
    }
    //this handles deleting an item in the database and returns if it could or not
    boolean deleteSingleItem(String rowId) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(InventoryTable.TABLE, "_id=?", new String[]{rowId});

        if (result == -1) {
            Toast.makeText(context, "Failed to Delete Item!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Deleted Item!", Toast.LENGTH_SHORT).show();
        }
        db.close(); // Close the database connection
        boolean success = result != -1;

        if (success) {
            smsCheck(); // again checks the smsCheck function
        }
        return success;
    }
    //sms function to send notification when inventory is low
    void smsCheck() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryTable.TABLE + " WHERE count < 5", null);

        // Check for items with low stock
        try {
            while (cursor != null && cursor.moveToNext()) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    // Get item name and stock count
                    String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NAME));
                    int stock = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_COUNT));

                    // Create SMS message
                    String message = "WARNING: Item named " + itemName + " has low stock (" + stock + " units)!";

                    // Specify the recipient number
                    String recipientNumber = "5551234567"; //  this is the number of my emulator

                    // Send SMS message, added this because i was not seeing the notifications on the emulator
                    try {
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(recipientNumber, null, message, null, null);
                        Toast.makeText(context, "SMS sent for low stock on: " + itemName, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(context, "Failed to send SMS for low stock on: " + itemName, Toast.LENGTH_SHORT).show();
                        e.printStackTrace(); // Log exception for debugging
                    }
                }
            }
        } finally {
            if (cursor != null) {
                cursor.close(); // Close the cursor
            }
            db.close(); // Close the database connection
        }
    }
}
