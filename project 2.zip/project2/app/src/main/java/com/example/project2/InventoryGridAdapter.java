package com.example.project2;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

public class InventoryGridAdapter extends BaseAdapter {

    private Context context;
    private Cursor cursor;

    public InventoryGridAdapter(Context context, Cursor cursor) {
        this.context = context;
        this.cursor = cursor;
    }

    @Override
    public int getCount() {
        return cursor.getCount();
    }

    @Override
    public Object getItem(int position) {
        if (cursor.moveToPosition(position)) {
            return cursor;
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        if (cursor.moveToPosition(position)) {
            return cursor.getLong(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_ID));
        }
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflate item_inventory layout
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.item_inventory, parent, false);
        }

        // Get data from cursor
        if (cursor.moveToPosition(position)) {
            String name = cursor.getString(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_NAME));
            String description = cursor.getString(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_DESCRIPTION));
            int count = cursor.getInt(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_COUNT));
            long itemId = getItemId(position);

            // Set data to views
            TextView nameTextView = convertView.findViewById(R.id.name_text_view);
            TextView descriptionTextView = convertView.findViewById(R.id.description_text_view);
            TextView countTextView = convertView.findViewById(R.id.count_text_view);
            Button updateButton = convertView.findViewById(R.id.UpdateSaveButton);

            nameTextView.setText(name);
            descriptionTextView.setText(description);
            countTextView.setText(String.valueOf(count));

            // Find the update button and set the OnClickListener
            if (updateButton != null) {
                updateButton.setOnClickListener(v -> {
                    // Handle updating the item when the button is clicked
                    Intent intent = new Intent(context, updateItem.class);
                    intent.putExtra("itemId", itemId); // Pass the item ID to the update activity
                    context.startActivity(intent);
                });
            }
        }
        return convertView;
    }

    public void swapCursor(Cursor newCursor) {
        if (cursor != null) {
            cursor.close();
        }
        cursor = newCursor;
        notifyDataSetChanged();
    }
}
