package com.example.project2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.material.snackbar.Snackbar;

public class updateItem extends AppCompatActivity {

    private EditText editName;
    private EditText editDescription;
    private EditText editCount;
    private Button saveButton;

    private Button deleteButton;
    private displayDatabase databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_item);

        // InitElements
        editName = findViewById(R.id.editName);
        editDescription = findViewById(R.id.editDescription);
        editCount = findViewById(R.id.editCount);
        saveButton = findViewById(R.id.UpdateSaveButton);
        deleteButton = findViewById(R.id.DeleteButton);

        // Initialize database helper
        databaseHelper = new displayDatabase(this); // makes the databasehelper for the app

        // Get the item ID from the intent extras
        long itemId = getIntent().getLongExtra("itemId", -1);

        // Load item details from the database and populate the form fields
        loadItemDetails(itemId);

        // Handle save button click
        saveButton.setOnClickListener(v -> handleSaveButtonClick(itemId, v));

        //convert itemId from long to int
        int itemIdInt = (int) itemId;
        //handle delete button click
        deleteButton.setOnClickListener(v -> handleDeleteButtonClick(itemIdInt, v));
    }

    private void loadItemDetails(long itemId) {
        Cursor cursor = databaseHelper.getItemById((int) itemId);
        if (cursor != null && cursor.moveToFirst()) {
            editName.setText(cursor.getString(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_NAME)));
            editDescription.setText(cursor.getString(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_DESCRIPTION)));
            editCount.setText(String.valueOf(cursor.getInt(cursor.getColumnIndex(displayDatabase.InventoryTable.COL_COUNT))));
            cursor.close();
        } else {
            // Handle error: item not found or cursor is null
            Snackbar.make(findViewById(android.R.id.content), "Item not found", Snackbar.LENGTH_SHORT).show();
            finish();
        }
    }

    private void handleSaveButtonClick(long itemId, View v) {
        // Get updated values from form fields
        String updatedName = editName.getText().toString().trim();
        String updatedDescription = editDescription.getText().toString().trim();
        String updatedCountString = editCount.getText().toString().trim();

        // Validate input
        if (updatedName.isEmpty() || updatedDescription.isEmpty() || updatedCountString.isEmpty()) {
            Snackbar.make(v, "Please fill in all fields", Snackbar.LENGTH_SHORT).show();
            return;
        }

        // from count to string
        int updatedCount;
        try {
            updatedCount = Integer.parseInt(updatedCountString);
        } catch (NumberFormatException e) {
            Snackbar.make(v, "Invalid count value", Snackbar.LENGTH_SHORT).show();
            return;
        }

        // Update item in the database
        boolean updateSuccess = databaseHelper.editItem(String.valueOf(itemId), updatedName, updatedDescription, updatedCount);

        // feedback when done
        if (updateSuccess) {
            Snackbar.make(v, "Item updated successfully", Snackbar.LENGTH_SHORT).show();
            finish(); // Finish activity and go back to inventory grid view
        } else {
            Snackbar.make(v, "Failed to update item", Snackbar.LENGTH_SHORT).show();
        }
    }

    //handles the delete button and then navigating back to inventory display when done
    private void handleDeleteButtonClick(long itemId, View v) {
        // Convert itemId to string
        String itemIdString = String.valueOf(itemId);

        // Delete the item from the database
        boolean deleteSuccess = databaseHelper.deleteSingleItem(itemIdString);

        // Navigate back to the display inventory screen if deletion is successful
        if (deleteSuccess) {
            Intent intent6 = new Intent(this, displayInventoryActivity.class);
            startActivity(intent6);
        }
        finish(); // Close the current activity
    }
}
