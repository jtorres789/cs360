package com.example.project2;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private Cursor cursor;

    public InventoryAdapter(Cursor cursor) {
        this.cursor = cursor;
    }

    /**
     * Update the cursor with new data and notify the adapter of the change.
     * @param newCursor The new cursor to use.
     */
    public void updateCursor(Cursor newCursor) {
        if (cursor != null) {
            cursor.close(); // Close the old cursor
        }
        cursor = newCursor;
        notifyDataSetChanged(); // Notify the adapter about the data change
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        if (cursor != null && cursor.moveToPosition(position)) {
            // Use getColumnIndex to avoid hardcoded column indices
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
            int count = cursor.getInt(cursor.getColumnIndexOrThrow("count"));

            // Set the data in the views
            holder.nameTextView.setText(name);
            holder.descriptionTextView.setText(description);
            holder.countTextView.setText(String.valueOf(count));
        }
    }

    @Override
    public int getItemCount() {
        return (cursor != null) ? cursor.getCount() : 0;
    }

    /**
     * ViewHolder class for inventory items.
     */
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView descriptionTextView;
        TextView countTextView;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.name_text_view);
            descriptionTextView = itemView.findViewById(R.id.description_text_view);
            countTextView = itemView.findViewById(R.id.count_text_view);
        }
    }
}
