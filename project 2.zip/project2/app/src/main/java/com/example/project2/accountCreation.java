package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class accountCreation extends AppCompatActivity {


    //naming variables
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button createButton;
    private UserRepository userRepository;

    @Override // creates instance for buttons and other functions
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        // Initialize views and UserRepository
        initializeViews();
        userRepository = new UserRepository(new UserData(this));

        // Set click listener for the create button
        createButton.setOnClickListener(view -> handleCreateAccount());
    }

    // Initialize views and links them to the buttons on the xml
    private void initializeViews() {
        usernameEditText = findViewById(R.id.CreateUsername);
        passwordEditText = findViewById(R.id.CreateAccountPassword);
        createButton = findViewById(R.id.CreateAccountbutton);
    }

    // Handle account creation connecting to userRepository
    private void handleCreateAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate inputs if empty
        if (username.isEmpty() || password.isEmpty()) {
            showToast("Please enter a username and password");
            return;
        }

        // Create a new user account, will add the user, if already there will show not possible
        boolean isCreated = userRepository.addUser(username, password);
        if (isCreated) {
            showToast("Account created successfully");
            navigateToWelcomeScreen(); //calls function to go to welcome screen
        } else {
            showToast("Account creation failed. Username may already exist.");
        }
    }

    // Show toast message, handles toasts in the code
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // Navigate back to welcome screen
    private void navigateToWelcomeScreen() {
        Intent intent = new Intent(this, WelcomeScreen.class);
        startActivity(intent);
    }
}
