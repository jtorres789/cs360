package com.example.project2;
public class UserRepository {
    private UserData userDataHelper;

    public UserRepository(UserData userDataHelper) {
        this.userDataHelper = userDataHelper;
    }

    // Method for adding a user
    public boolean addUser(String username, String password) {
        return userDataHelper.addUser(username, password);
    }

    // Method for authenticating a user
    public boolean authenticateUser(String username, String password) {
        return userDataHelper.isUserValid(username, password);
    }
}

