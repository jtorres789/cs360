package com.example.project2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class displayInventoryActivity extends AppCompatActivity {

    private static final int UPDATE_ITEM_REQUEST_CODE = 2;

    private static final int NEW_ITEM_REQUEST_CODE = 1;
    private GridView inventoryGridView;
    private InventoryGridAdapter inventoryAdapter;
    private displayDatabase databaseHelper;
    private Button addItemButton;

    private Button goBackButton; // added the go back button for App transition smoothness

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_inventory);

        // Initialize GridView and DatabaseHelper
        inventoryGridView = findViewById(R.id.inventory_grid_view);
        databaseHelper = new displayDatabase(this);

        // Initialize adapter and set it to GridView
        Cursor cursor = databaseHelper.readItems();
        inventoryAdapter = new InventoryGridAdapter(this, cursor);
        inventoryGridView.setAdapter(inventoryAdapter);

        // Set click listener on the Add Item button
        addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(view -> {
            // Create an Intent to start NewItemToInventory activity
            Intent intent = new Intent(displayInventoryActivity.this, newItemToInventory.class);
            startActivityForResult(intent, NEW_ITEM_REQUEST_CODE);
        });

        goBackButton = findViewById(R.id.goBackButton);
        goBackButton.setOnClickListener(view -> {
            Intent intent9 = new Intent(displayInventoryActivity.this, WelcomeScreen.class);
            startActivity(intent9);
        });


        // Set OnItemClickListener for the GridView, not sure why its red but works fine the code
        inventoryGridView.setOnItemClickListener((parent, view, position, id) -> {
            Cursor clickedCursor = (Cursor) parent.getItemAtPosition(position);
            long itemId = clickedCursor.getLong(clickedCursor.getColumnIndex(displayDatabase.InventoryTable.COL_ID));

            // Start updateItem activity and pass the selected item ID
            Intent intent = new Intent(displayInventoryActivity.this, updateItem.class);
            intent.putExtra("itemId", itemId);
            startActivityForResult(intent, UPDATE_ITEM_REQUEST_CODE);//not sure why its strikethrough but works fine the code
        });
    }

    // Handle the result from NewItemToInventory and updateItem activities
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // Refresh the inventory grid when returning from the activities
            Cursor cursor = databaseHelper.readItems(); // had to add this beacuse when I was going back from the update screen it was not showing the update.
            inventoryAdapter.swapCursor(cursor);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the grid by updating the cursor in the adapter
        Cursor cursor = databaseHelper.readItems(); // this one beacause when adding an item it was not showing
        inventoryAdapter.swapCursor(cursor);
    }
}
