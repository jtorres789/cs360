package com.example.project2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class newItemToInventory extends AppCompatActivity {
    //naming variables
    private EditText nameEditText;
    private EditText descriptionEditText;
    private EditText countEditText;
    private Button saveButton;
    private displayDatabase databaseHelper;

    @Override //conneting to the xml file
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item_to_inventory);

        initElements();
        initDatabaseHelper();

        saveButton.setOnClickListener(this::handleSaveButtonClick);
    }
    //initialize elemets and connecting them to the widgets int he xml file
    private void initElements() {
        nameEditText = findViewById(R.id.NewItemName);
        descriptionEditText = findViewById(R.id.newItemDescription);
        countEditText = findViewById(R.id.newItemCount);
        saveButton = findViewById(R.id.SaveNewItemButton);
    }
    //this connects to the database
    private void initDatabaseHelper() {
        databaseHelper = new displayDatabase(this);
    }
    //this handles the save button click and making the count a string
    private void handleSaveButtonClick(View view) {
        // Get user input from EditText fields
        String name = nameEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        int count;
        try {
            count = Integer.parseInt(countEditText.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid count value", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add the new item to the database
        boolean isAdded = databaseHelper.addItem(name, description, count); //

        if (isAdded) {
            // Item added successfully
            Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
        } else {
            // Failed to add the item
            Toast.makeText(this, "Failed to add the item", Toast.LENGTH_SHORT).show();
        }
    }
}
