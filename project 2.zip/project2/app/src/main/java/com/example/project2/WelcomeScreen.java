package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        // Find buttons in the layout by their ID
        Button buttonInv = findViewById(R.id.InventoryButton);

        Button buttonSMS = findViewById(R.id.SMSButton);

        Button ExitButton = findViewById(R.id.ExitButton);

        // Set an OnClicker for to go to the inventory Page
        buttonInv.setOnClickListener(v -> {
            // Call the displayInventory function when button1 is clicked
            Intent intent6 = new Intent(WelcomeScreen.this, displayInventoryActivity.class);
            startActivity(intent6);
        });

        // Set an OnClicker to go to the Enable SMS notification Page
        buttonSMS.setOnClickListener(v -> {
            // Call the displayInventory function when button1 is clicked
            Intent intent7 = new Intent(WelcomeScreen.this, SMSPage.class);
            startActivity(intent7);
        });

        // Set an OnClicker for button to exit the app
        ExitButton.setOnClickListener(v -> {
            finishAffinity();
            System.exit(0);
        });
    }
}

